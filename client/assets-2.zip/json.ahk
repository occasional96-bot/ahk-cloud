; ============================================================
; json.ahk - minimal JSON parser for WorkspaceClient posted scripts
; Auto-#Included by the client into any posted AHK script that
; references "JSON". Provides:
;   obj := JSONParse(text)   ; returns nested AHK objects/arrays
; Same implementation as the client's built-in parser.
; ============================================================
JSONParse(text) {
pos := 1
return JSON_Value(text, pos)
}
JSON_Skip(ByRef text, ByRef pos) {
while (pos <= StrLen(text)) {
c := SubStr(text, pos, 1)
if (c = " " || c = "`t" || c = "`n" || c = "`r")
pos++
else
break
}
}
JSON_Value(ByRef text, ByRef pos) {
JSON_Skip(text, pos)
c := SubStr(text, pos, 1)
if (c = "{")
return JSON_Object(text, pos)
if (c = "[")
return JSON_Array(text, pos)
if (c = """")
return JSON_String(text, pos)
if (c = "t" || c = "f")
return JSON_Bool(text, pos)
if (c = "n") {
pos += 4
return ""
}
return JSON_Number(text, pos)
}
JSON_Object(ByRef text, ByRef pos) {
obj := {}
pos++
JSON_Skip(text, pos)
if (SubStr(text, pos, 1) = "}") {
pos++
return obj
}
loop {
JSON_Skip(text, pos)
key := JSON_String(text, pos)
JSON_Skip(text, pos)
pos++
val := JSON_Value(text, pos)
obj[key] := val
JSON_Skip(text, pos)
nc := SubStr(text, pos, 1)
if (nc = ",") {
pos++
continue
}
if (nc = "}") {
pos++
break
}
break
}
return obj
}
JSON_Array(ByRef text, ByRef pos) {
arr := []
pos++
JSON_Skip(text, pos)
if (SubStr(text, pos, 1) = "]") {
pos++
return arr
}
loop {
val := JSON_Value(text, pos)
arr.Push(val)
JSON_Skip(text, pos)
nc := SubStr(text, pos, 1)
if (nc = ",") {
pos++
continue
}
if (nc = "]") {
pos++
break
}
break
}
return arr
}
JSON_String(ByRef text, ByRef pos) {
pos++
out := ""
while (pos <= StrLen(text)) {
c := SubStr(text, pos, 1)
if (c = """") {
pos++
return out
}
if (c = "\") {
pos++
esc := SubStr(text, pos, 1)
if (esc = "n")
out .= "`n"
else if (esc = "r")
out .= "`r"
else if (esc = "t")
out .= "`t"
else if (esc = """")
out .= """"
else if (esc = "\")
out .= "\"
else if (esc = "/")
out .= "/"
else if (esc = "b")
out .= Chr(8)
else if (esc = "f")
out .= Chr(12)
else if (esc = "u") {
hex := SubStr(text, pos+1, 4)
out .= Chr("0x" . hex)
pos += 4
} else
out .= esc
pos++
} else {
out .= c
pos++
}
}
return out
}
JSON_Number(ByRef text, ByRef pos) {
start := pos
while (pos <= StrLen(text)) {
c := SubStr(text, pos, 1)
if c is number
pos++
else if (c = "." || c = "-" || c = "+" || c = "e" || c = "E")
pos++
else
break
}
return SubStr(text, start, pos - start) + 0
}
JSON_Bool(ByRef text, ByRef pos) {
if (SubStr(text, pos, 4) = "true") {
pos += 4
return true
}
pos += 5
return false
}
